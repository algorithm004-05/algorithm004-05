<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1570604628011" ID="ID_1485173948" MODIFIED="1570613501222" TEXT="&#x6570;&#x636e;&#x7ed3;&#x6784;">
<font NAME="&#x5fae;&#x8f6f;&#x96c5;&#x9ed1;" SIZE="12"/>
<node CREATED="1570605383127" ID="ID_1126332442" MODIFIED="1570634610141" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38750;&#21463;&#38480;&#32447;&#24615;&#34920;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570634685328" ID="ID_1379246150" MODIFIED="1570634739763">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#39034;&#24207;&#32467;&#26500;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570634752512" ID="ID_681458932" MODIFIED="1570634779681" TEXT="&#x6570;&#x7ec4;">
<node CREATED="1570681583044" ID="ID_1277388697" MODIFIED="1570681598436">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20998;&#31867;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570681600627" ID="ID_1004604431" MODIFIED="1570681652777">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#19968;&#32500;&#25968;&#32452; String[] arr1 = new String[10]
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570681605224" ID="ID_1819947052" MODIFIED="1570682138230">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20108;&#32500;&#25968;&#32452; String[][] arr2 = new String[1024][10]&#160;&#160;10&#20195;&#34920;&#19968;&#32500;&#25968;&#32452;&#30340;&#22823;&#23567;&#160; 1024&#20195;&#34920;&#23384;&#25918;&#30340;&#19968;&#32500;&#25968;&#32452;&#30340;&#20010;&#25968;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570682147032" ID="ID_1283707436" MODIFIED="1570682156963" TEXT="&#x6811;&#x72b6;&#x6570;&#x7ec4;"/>
</node>
<node CREATED="1570681037891" ID="ID_734929601" MODIFIED="1570681204680">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      CPU&#32531;&#23384;&#26368;&#23567;&#21333;&#20301;&#26159;&#32531;&#23384;&#34892;&#65292;&#32531;&#23384;&#34892;&#22823;&#23567;&#21462;&#20915;&#19982;CPU&#65292;&#27178;&#21521;&#36941;&#21382;&#25968;&#32452;&#21487;&#20197;&#20943;&#23569;CPU&#19982;&#20027;&#23384;&#30340;&#20132;&#20114;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570623034193" ID="ID_563563813" MODIFIED="1570634825877">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25903;&#25345;&#65327;&#65288;&#65297;&#65289;&#30340;&#38543;&#26426;&#35775;&#38382;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570634799915" ID="ID_1169567603" MODIFIED="1570634885095">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24179;&#22343;&#20026;&#65327;&#65288;&#65358;&#65289;&#30340;&#21024;&#38500;&#21644;&#25554;&#20837;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570634767025" ID="ID_361387135" MODIFIED="1570634935233">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35686;&#24789;&#36234;&#30028;&#38169;&#35823;&#65292;&#23548;&#33268;stack over flow
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1570634689221" ID="ID_433994380" MODIFIED="1570635067231">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38142;&#24335;&#32467;&#26500;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570635013522" ID="ID_71180149" MODIFIED="1570635076722">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21333;&#38142;&#24335;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570609403704" ID="ID_996791537" MODIFIED="1570635206492">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#19981;&#25903;&#25345;&#38543;&#26426;&#35775;&#38382;&#65292;&#38656;&#35201;&#36941;&#21382;&#21435;&#35775;&#38382;&#32467;&#28857;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570635024882" ID="ID_689541603" MODIFIED="1570635274401">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25554;&#20837;&#21644;&#21024;&#38500;&#21482;&#38656;&#35201;&#31227;&#21160;&#25351;&#38024;&#65292;&#26102;&#38388;&#22797;&#26434;&#24230;&#20026;O&#65288;1&#65289;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570635026437" ID="ID_1681964354" MODIFIED="1570635336584">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27599;&#20010;&#32467;&#28857;&#38656;&#35201;&#39069;&#22806;&#30340;&#20869;&#23384;&#21435;&#23384;&#20648;&#25351;&#38024;&#65292;&#38656;&#35201;&#30340;&#20869;&#23384;&#27604;&#25968;&#32452;&#22823;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1570635016770" ID="ID_170394762" MODIFIED="1570635090490">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21452;&#38142;&#24335;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570638703357" ID="ID_1745911942" MODIFIED="1570638770806">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22312;&#21333;&#38142;&#24335;&#30340;&#22522;&#30784;&#19978;&#65292;&#38500;&#22836;&#32467;&#28857;&#22806;&#65292;&#27599;&#20010;&#32467;&#28857;&#22810;&#20102;&#19968;&#20010;&#23384;&#25918;&#21069;&#39537;&#32467;&#28857;&#30340;&#20869;&#23384;&#22320;&#22336;&#30340;&#25351;&#38024;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1570635038722" ID="ID_1119495089" MODIFIED="1570635105370">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24490;&#29615;&#38142;&#24335;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570638780639" ID="ID_1669707678" MODIFIED="1570638826764">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23614;&#32467;&#28857;&#25351;&#38024;&#25351;&#21521;&#22836;&#32467;&#28857;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1570635106619" ID="ID_429370627" MODIFIED="1570635121061">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38745;&#24577;&#38142;&#24335;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570638850913" ID="ID_1065126640" MODIFIED="1570638890481">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20511;&#21161;&#25968;&#32452;&#65292;&#20276;&#38543;&#25351;&#21521;&#21518;&#32487;&#32467;&#28857;&#30340;&#25351;&#38024;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
<node CREATED="1570623466335" ID="ID_165119304" MODIFIED="1570638933093" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21463;&#38480;&#32447;&#24615;&#34920;
    </p>
  </body>
</html></richcontent>
<arrowlink DESTINATION="ID_165119304" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_410116276" STARTARROW="None" STARTINCLINATION="0;0;"/>
<linktarget COLOR="#b0b0b0" DESTINATION="ID_165119304" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_410116276" SOURCE="ID_165119304" STARTARROW="None" STARTINCLINATION="0;0;"/>
<node CREATED="1570623610807" ID="ID_1824202904" MODIFIED="1570638995252">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26632;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570638997676" ID="ID_581730291" MODIFIED="1570639053423">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#39034;&#24207;&#21644;&#38142;&#24335;&#37117;&#21487;&#20197;&#23454;&#29616;&#65292;&#20808;&#36827;&#21518;&#20986;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570639065580" ID="ID_432426866" MODIFIED="1570639093148">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23454;&#38469;&#24212;&#29992;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570639094986" ID="ID_651191400" MODIFIED="1570639137979">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#27983;&#35272;&#22120;&#30340;&#21069;&#36827;&#19982;&#21518;&#36864;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570639099515" ID="ID_1341989425" MODIFIED="1570858899341">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25324;&#21495;&#21305;&#37197;&#65311;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570639101068" ID="ID_18227707" MODIFIED="1570858904144">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#34920;&#36798;&#24335;&#35745;&#31639;&#65311;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node CREATED="1570623760899" ID="ID_563446299" MODIFIED="1570639231762">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22534;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570639233223" ID="ID_1568424809" MODIFIED="1570639252542">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22823;&#39030;&#22534;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570639237806" ID="ID_1378235058" MODIFIED="1570639260640">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23567;&#39030;&#22534;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570639238966" ID="ID_1327295575" MODIFIED="1570639271547">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23454;&#38469;&#24212;&#29992;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570639273249" ID="ID_478370485" MODIFIED="1570639316144">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25214;&#31532;K&#22823;&#20803;&#32032;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1570639339646" ID="ID_934440678" MODIFIED="1570639352106">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38431;&#21015;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570639355118" ID="ID_283011571" MODIFIED="1570639372112">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26222;&#36890;&#38431;&#21015;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570639454238" ID="ID_1094829041" MODIFIED="1570639489463" TEXT="&#x987a;&#x5e8f;&#x548c;&#x94fe;&#x5f0f;&#x90fd;&#x53ef;&#x4ee5;&#x5b9e;&#x73b0;&#xff0c;&#x5148;&#x8fdb;&#x5148;&#x51fa;"/>
</node>
<node CREATED="1570639358011" ID="ID_43361391" MODIFIED="1570639385597">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21452;&#36793;&#38431;&#21015;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570639493272" ID="ID_1207439978" MODIFIED="1570639532852">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20837;&#21475;&#21644;&#20986;&#21475;&#37117;&#21487;&#20197;&#36827;&#38431;&#21644;&#20986;&#38431;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1570639359023" ID="ID_1140045581" MODIFIED="1570639406147">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20248;&#20808;&#32423;&#38431;&#21015;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570639535586" ID="ID_1122787872" MODIFIED="1570639556104">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26681;&#25454;&#20248;&#20808;&#32423;&#20986;&#38431;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1570639359961" ID="ID_1121375878" MODIFIED="1570639421618">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23454;&#38469;&#24212;&#29992;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570639423227" ID="ID_1143457369" MODIFIED="1570639444248" TEXT="LRU Cacle"/>
</node>
</node>
</node>
<node CREATED="1570639773128" ID="ID_907341694" MODIFIED="1570640605459" POSITION="left" TEXT="&#x6811;&#x4e0e;&#x4e8c;&#x53c9;&#x6811;">
<node CREATED="1570639832292" ID="ID_253954371" MODIFIED="1570639851337">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#29305;&#28857;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570640102088" ID="ID_452181714" MODIFIED="1570640156736">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#39034;&#24207;&#21644;&#38142;&#34920;&#37117;&#21487;&#20197;&#23454;&#29616;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570640125909" ID="ID_1943490840" MODIFIED="1570640186743">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36941;&#21382;&#26041;&#24335;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570640196196" ID="ID_1017092656" MODIFIED="1570640449228">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24191;&#24230;&#20248;&#20808;&#25628;&#32034;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570640117089" ID="ID_191196106" MODIFIED="1570640459943">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#28145;&#24230;&#20248;&#20808;&#25628;&#32034;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570640385781" ID="ID_1452009839" MODIFIED="1570640396195">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21069;&#24207;&#36941;&#21382;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570640397741" ID="ID_456867187" MODIFIED="1570640403590" TEXT="&#x4e2d;&#x5e8f;&#x904d;&#x5386;"/>
<node CREATED="1570640404461" ID="ID_1931291912" MODIFIED="1570640410567" TEXT="&#x540e;&#x5e8f;&#x904d;&#x5386;"/>
</node>
</node>
</node>
<node CREATED="1570640469175" ID="ID_871012447" MODIFIED="1570640633374">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20108;&#21449;&#26641;
    </p>
  </body>
</html></richcontent>
<node CREATED="1570640635964" ID="ID_1865391618" MODIFIED="1570640708659">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23436;&#20840;&#20108;&#21449;&#26641;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570640642632" ID="ID_916952127" MODIFIED="1570640649783" TEXT="&#x6ee1;&#x4e8c;&#x53c9;&#x6811;"/>
<node CREATED="1570640650194" ID="ID_1900427134" MODIFIED="1570640692538">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20108;&#21449;&#25628;&#32034;&#26641;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570640662427" ID="ID_270615887" MODIFIED="1570640676911" TEXT="&#x5e73;&#x8861;&#x4e8c;&#x53c9;&#x6811;">
<node CREATED="1570640712358" ID="ID_725677546" MODIFIED="1570640723581">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32418;&#40657;&#26641;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1570640501778" ID="ID_26220864" MODIFIED="1570640897427">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21704;&#22827;&#26364;&#26641;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570640510793" ID="ID_156035606" MODIFIED="1570640907669">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#23383;&#20856;&#26641;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1570640584372" ID="ID_1258935136" MODIFIED="1570640591223" POSITION="left" TEXT="&#x56fe;">
<node CREATED="1570640928951" ID="ID_1766030738" MODIFIED="1570640963583">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20026;&#20160;&#20040;&#35813;&#33041;&#22270;&#20013;&#27809;&#26377;&#22270;&#36825;&#31181;&#25968;&#25454;&#32467;&#26500;&#21602;&#65311;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570640966694" ID="ID_1060036288" MODIFIED="1570641004831" TEXT="&#x96c6;&#x5408;&#x548c;&#x6620;&#x5c04;&#x53c8;&#x5c5e;&#x4e8e;&#x8be5;&#x6570;&#x636e;&#x8111;&#x56fe;&#x4e2d;&#x54ea;&#x4e00;&#x90e8;&#x5206;"/>
</node>
<node CREATED="1570680225011" ID="ID_182091339" MODIFIED="1570680235919" POSITION="left" TEXT="&#x6392;&#x5e8f;&#x7b97;&#x6cd5;">
<node CREATED="1570680263661" ID="ID_1186999762" MODIFIED="1570680309800">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      O(n^2)
    </p>
  </body>
</html></richcontent>
<node CREATED="1570680312521" ID="ID_354972303" MODIFIED="1570680333550">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20882;&#27873;&#25490;&#24207;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570680316909" ID="ID_1741643257" MODIFIED="1570680341570">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25554;&#20837;&#25490;&#24207;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570680319044" ID="ID_1969914931" MODIFIED="1570680360277">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36873;&#25321;&#25490;&#24207;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1570680268768" ID="ID_1320263176" MODIFIED="1570680397454">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      On(logn)
    </p>
  </body>
</html></richcontent>
<node CREATED="1570680399321" ID="ID_572424585" MODIFIED="1570680430507">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24555;&#36895;&#25490;&#24207;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570680402759" ID="ID_1226770917" MODIFIED="1570680438232">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24402;&#24182;&#25490;&#24207;
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1570680270412" ID="ID_1940560993" MODIFIED="1570680469130" TEXT="O(n)">
<node CREATED="1570680445893" ID="ID_1245644258" MODIFIED="1570680565214">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26742;&#25490;&#24207;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570680448967" ID="ID_1497741611" MODIFIED="1570680568587">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#35745;&#25968;&#25490;&#24207;
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1570680473352" ID="ID_1328977719" MODIFIED="1570680573091">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22522;&#25968;&#25490;&#24207;
    </p>
  </body>
</html></richcontent>
</node>
</node>
</node>
</node>
</map>
