<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1570877986018" ID="ID_1103962201" MODIFIED="1570878001139" TEXT="&#x7b97;&#x6cd5;">
<node CREATED="1570878002681" ID="ID_305170673" MODIFIED="1570878870387" POSITION="right" TEXT="&#x5de5;&#x5177;">
<node CREATED="1570878977775" ID="ID_505832124" MODIFIED="1570879009950">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      google&#25628;&#32034;&#24341;&#25806;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570879018544" ID="ID_709885608" MODIFIED="1570879034995" TEXT="iterm2+zsh&#x6700;&#x5f3a;&#x7ec8;&#x7aef;&#x4f53;&#x9a8c;"/>
<node CREATED="1570879041582" ID="ID_216660931" MODIFIED="1570879052768" TEXT="heyfocus.com"/>
<node CREATED="1570879063360" ID="ID_1124373916" MODIFIED="1570879103359" TEXT="IDEA + LeetCode Plugin"/>
<node CREATED="1570879104421" ID="ID_1739551176" MODIFIED="1570879122392" TEXT="LeetCode"/>
</node>
<node CREATED="1570878871021" ID="ID_683111932" MODIFIED="1570878875689" POSITION="right" TEXT="&#x590d;&#x6742;&#x5ea6;">
<node CREATED="1570879195773" ID="ID_1922647587" MODIFIED="1570879206434">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26102;&#38388;&#22797;&#26434;&#24230;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1570879242074" ID="ID_1991423009" MODIFIED="1570879353192">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      O(1)&#24120;&#25968;&#22797;&#26434;&#24230;&#65292;&#26368;&#20339;&#65292;&#22914;hash&#34920;&#21644;&#32531;&#23384;&#31561;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570879355180" ID="ID_1362815644" MODIFIED="1570879416719">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      O(log(n))&#20165;&#27425;&#20110;&#24120;&#25968;&#22797;&#26434;&#24230;&#65292;&#22914;&#20108;&#20998;&#26597;&#25214;&#21644;&#20108;&#21449;&#25628;&#32034;&#26641;&#31561;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570879420822" ID="ID_838810390" MODIFIED="1570879462461">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      O(n)&#32447;&#24615;&#22797;&#26434;&#24230;&#65292;&#22914;&#22823;&#22810;&#25968;&#30340;&#36941;&#21382;&#25805;&#20316;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570879463424" ID="ID_880127975" MODIFIED="1570879506712">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      O(n^2)&#21452;&#37325;for&#24490;&#29615;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570879515354" ID="ID_1584282689" MODIFIED="1570879567217">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      O(2^n)&#36882;&#24402;&#30340;&#26102;&#38388;&#22797;&#26434;&#24230;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570879208420" ID="ID_657160120" MODIFIED="1570879215396" TEXT="&#x7a7a;&#x95f4;&#x590d;&#x6742;&#x5ea6;">
<node CREATED="1570879613636" ID="ID_1618430550" MODIFIED="1570879631130" TEXT="O(1)&#x539f;&#x5730;&#x64cd;&#x4f5c;"/>
<node CREATED="1570879632345" ID="ID_1462979112" MODIFIED="1570879655683" TEXT="O(n)&#x5f00;&#x8f9f;&#x7ebf;&#x6027;&#x8f85;&#x52a9;&#x7a7a;&#x95f4;"/>
</node>
</node>
<node CREATED="1570878876099" ID="ID_1417598957" MODIFIED="1570878889770" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#25968;&#32452;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1570880217000" ID="ID_1181620588" MODIFIED="1570881738324">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36830;&#32493;&#31354;&#38388;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570880234873" ID="ID_1594035535" MODIFIED="1570880254452" TEXT="&#x67e5;&#x8be2;&#x5feb;&#xff0c;&#x5220;&#x9664;&#x63d2;&#x5165;&#x8282;&#x70b9;&#x6162;"/>
</node>
<node CREATED="1570878893389" ID="ID_1192195207" MODIFIED="1570878899126" POSITION="right" TEXT="&#x94fe;&#x8868;">
<node CREATED="1570881749139" ID="ID_734457672" MODIFIED="1570881762135">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#31163;&#25955;&#31354;&#38388;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570881763095" ID="ID_1408762042" MODIFIED="1570881783026">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26597;&#35810;&#24930;&#65292;&#25554;&#20837;&#21024;&#38500;&#33410;&#28857;&#24555;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570878899485" ID="ID_1777962298" MODIFIED="1570878917058" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26632;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1570881802216" ID="ID_1766835118" MODIFIED="1570881812109">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20808;&#36827;&#21518;&#20986;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570878905610" ID="ID_687269036" MODIFIED="1570878936749" POSITION="right">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38431;&#21015;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1570881814194" ID="ID_273393396" MODIFIED="1570881825838">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20808;&#36827;&#20808;&#20986;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570878948860" ID="ID_1496506036" MODIFIED="1570878951987" POSITION="right" TEXT="&#x6620;&#x5c04;">
<node CREATED="1570881860968" ID="ID_1628634936" MODIFIED="1570881886279">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      K/V&#20943;&#20540;&#23545;&#65292;key&#20540;&#19981;&#37325;&#22797;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570878952460" ID="ID_443093680" MODIFIED="1570878956005" POSITION="right" TEXT="&#x96c6;&#x5408;">
<node CREATED="1570881888837" ID="ID_853341079" MODIFIED="1570881899539">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      key&#20540;&#19981;&#37325;&#22797;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570878956339" ID="ID_1537181490" MODIFIED="1570952257763" POSITION="right" TEXT="&#x5e76;&#x67e5;&#x96c6;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1570881902167" ID="ID_715484511" MODIFIED="1570881913895">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#31449;&#38431;&#38382;&#39064;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570881915373" ID="ID_976357955" MODIFIED="1570881930660">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21021;&#22987;&#21270;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570881931454" ID="ID_633100232" MODIFIED="1570881937371" TEXT="&#x67e5;&#x8be2;&#x3001;&#x5408;&#x5e76;"/>
<node CREATED="1570881938101" ID="ID_1225048657" MODIFIED="1570881953107">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36335;&#24452;&#21387;&#32553;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570881959606" ID="ID_446758701" MODIFIED="1570952298747" POSITION="left" TEXT="&#x6811;">
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1570882752093" ID="ID_1817870059" MODIFIED="1570882764441">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20108;&#21449;&#26641;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1570882922833" ID="ID_846644495" MODIFIED="1570882938613">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36941;&#21382;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1570882939791" ID="ID_642159797" MODIFIED="1570882945875" TEXT="BFS"/>
<node CREATED="1570882946379" ID="ID_1813654154" MODIFIED="1570882949009" TEXT="DFS"/>
</node>
<node CREATED="1570882793346" ID="ID_961612449" MODIFIED="1570882865923">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#20108;&#21449;&#25628;&#32034;&#26641;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570882867203" ID="ID_1604501494" MODIFIED="1570882893476">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#24179;&#34913;&#20108;&#21449;&#26641;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1570882964233" ID="ID_790810745" MODIFIED="1570882976612">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      AVL&#26641;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570882977636" ID="ID_1469945607" MODIFIED="1570882999870">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32418;&#40657;&#26641;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570882894499" ID="ID_1913066212" MODIFIED="1570882919729">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21098;&#26525;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570882765540" ID="ID_1993171750" MODIFIED="1570882777408" TEXT="&#x5b57;&#x5178;&#x6811;">
<node CREATED="1570883014540" ID="ID_993806759" MODIFIED="1570883023341">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#31354;&#38388;&#25442;&#26102;&#38388;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node CREATED="1570882619300" ID="ID_1536811513" MODIFIED="1570882640195" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#22270;
    </p>
  </body>
</html>
</richcontent>
<node CREATED="1570883031930" ID="ID_1218027518" MODIFIED="1570883062406">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36941;&#21382;&#26102;&#38656;&#35201;&#35760;&#24405;&#24050;&#32463;&#35775;&#38382;&#36807;&#30340;&#33410;&#28857;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570882621977" ID="ID_1300401759" MODIFIED="1570952244574" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36882;&#24402;&#12289;&#20998;&#27835;
    </p>
  </body>
</html>
</richcontent>
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1570951568618" ID="ID_777418920" MODIFIED="1570951593231">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#30423;&#26790;&#31354;&#38388;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570951594408" ID="ID_827781742" MODIFIED="1570951609426">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#32456;&#27490;&#29366;&#24577;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570951612427" ID="ID_598559537" MODIFIED="1570951622947">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26412;&#23618;&#22788;&#29702;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570951627915" ID="ID_783308899" MODIFIED="1570951636101" TEXT="Drill Down"/>
<node CREATED="1570951640939" ID="ID_546094281" MODIFIED="1570951655161" TEXT="&#x672c;&#x5c42;&#x72b6;&#x6001;&#x6e05;&#x7406;"/>
</node>
<node CREATED="1570882658579" ID="ID_545682196" MODIFIED="1570882666198" POSITION="left" TEXT="&#x4e8c;&#x5206;&#x67e5;&#x627e;">
<node CREATED="1570951675240" ID="ID_1418145542" MODIFIED="1570951685351">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26377;&#24207;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570951686383" ID="ID_1950689895" MODIFIED="1570951690603" TEXT="&#x6709;&#x754c;"/>
<node CREATED="1570951692238" ID="ID_407123016" MODIFIED="1570951712287">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#33021;&#22815;&#36890;&#36807;&#32034;&#24341;&#38543;&#26426;&#35775;&#38382;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570882669699" ID="ID_301326808" MODIFIED="1570952238324" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#36138;&#24515;&#31639;&#27861;
    </p>
  </body>
</html>
</richcontent>
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1570951727155" ID="ID_1272504320" MODIFIED="1570951737938">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21028;&#26029;&#33021;&#19981;&#33021;&#36138;&#24515;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570951741960" ID="ID_943422396" MODIFIED="1570951749675" TEXT="&#x5f31;&#x5316;&#x7248;&#x7684;&#x52a8;&#x6001;&#x89c4;&#x5212;"/>
</node>
<node CREATED="1570882690738" ID="ID_205004017" MODIFIED="1570952232540" POSITION="left">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21160;&#24577;&#35268;&#21010;
    </p>
  </body>
</html>
</richcontent>
<icon BUILTIN="messagebox_warning"/>
<node CREATED="1570951782113" ID="ID_1926823247" MODIFIED="1570951802300">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#31616;&#21333;&#29256;&#26412;&#26159;&#36882;&#24402;&#21152;&#32531;&#23384;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570951803595" ID="ID_443173181" MODIFIED="1570951833702">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#39640;&#32423;&#29256;&#26412;&#26159;&#36882;&#25512;&#20844;&#24335;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570951845231" ID="ID_1501883819" MODIFIED="1570951849739" TEXT="&#x72b6;&#x6001;&#x7684;&#x5b9a;&#x4e49;">
<node CREATED="1570951899494" ID="ID_625029211" MODIFIED="1570951921244">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26377;&#20123;&#22330;&#26223;&#38656;&#35201;&#22871;&#29992;&#27169;&#26495;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570951850341" ID="ID_415115631" MODIFIED="1570951875671">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#26368;&#20248;&#23376;&#32467;&#26500;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570951876321" ID="ID_1172761458" MODIFIED="1570951896755">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#29366;&#24577;&#36716;&#31227;&#26041;&#31243;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570882726990" ID="ID_871003531" MODIFIED="1570882736857" POSITION="left" TEXT="&#x4f4d;&#x8fd0;&#x7b97;">
<node CREATED="1570951935265" ID="ID_866002222" MODIFIED="1570951953328">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#38656;&#35201;&#35760;&#24518;&#19968;&#20123;&#24120;&#29992;&#30340;&#20301;&#36816;&#31639;&#20844;&#24335;
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node CREATED="1570882698389" ID="ID_11529624" MODIFIED="1570882712500" POSITION="left" TEXT="&#x6b65;&#x9686;&#x8fc7;&#x6ee4;&#x5668;">
<node CREATED="1570952036139" ID="ID_544187246" MODIFIED="1570952049807">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21028;&#26029;&#19981;&#23384;&#22312;100%&#20934;&#30830;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570952050890" ID="ID_1763803456" MODIFIED="1570952072151">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      &#21028;&#26029;&#23384;&#22312;&#26377;&#35823;&#24046;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570952072932" ID="ID_569165405" MODIFIED="1570952098120" TEXT="&#x5229;&#x7528;hash&#x51fd;&#x6570;&#x5c06;&#x5f85;&#x5224;&#x65ad;&#x7684;key&#x5bf9;&#x5e94;&#x5230;&#x591a;&#x4e2a;&#x4f4d;&#x4e0a;"/>
</node>
<node CREATED="1570882713201" ID="ID_611491854" MODIFIED="1570882716601" POSITION="left" TEXT="LRU">
<node CREATED="1570952126383" ID="ID_320623716" MODIFIED="1570952176837">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Hash&#20989;&#25968;+&#21452;&#21521;&#38142;&#34920;
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1570952177851" ID="ID_987533344" MODIFIED="1570952205046" TEXT="get&#x548c;set&#x90fd;&#x662f;O(1)&#x590d;&#x6742;&#x5ea6;"/>
</node>
</node>
</map>
